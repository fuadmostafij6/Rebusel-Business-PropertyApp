class Constance {
  static const String authCode = "api_token";
  static const String id = "id";
  static const String user_type = "user_type";
  static const String urlHost = "http://v2.rebusel.com/api/v1";
}
